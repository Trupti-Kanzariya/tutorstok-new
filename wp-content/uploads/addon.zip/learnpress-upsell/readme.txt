=== LearnPress - Upsell ===
Contributors: thimpress, nhamdv
Donate link:
Tags: education, backend manager courses.
Tested up to: 6.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

== Changelog ==

= 4.0.6 (2024-03-05) =
~ Tweak: load this plugin before payment gateways of LearnPress.

= 4.0.5 (2024-11-13) =
~ Tweak: logic buy package.
~ Tweak: logic when LP Order change status.
~ Added: option show list coupon checkout page.
~ Added: show toast message when apply coupon, click button buy package.
~ Added: widget list packages for Elementor.

= 4.0.4 (2024-10-24) =
~ Tweak: style single, archive Package page.
~ Tweak: style list packages on the single course page.
~ Added: show list coupon on the LP Checkout page.

= 4.0.3 (2024-07-25) =
~ Fixed: apply coupon reload page lose information of another fields.
~ Added: defer js.

= 4.0.2 (2024-04-01) =
~ Fixed: display incorrect duration.
~ Fixed: missing some translations.
~ Compatible with addon LP Woo 4.1.4.

= 4.0.1 (2023-07-03) =
~ Added: feature Coupon.

= 4.0.0 (2023-04-19) =
~ Feature: buy package has included courses.

